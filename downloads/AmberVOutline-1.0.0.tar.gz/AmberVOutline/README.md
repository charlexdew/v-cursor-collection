# Amber V Outline

Author: charlexdew. License: MIT. Version: 1.0.0.

Scalable SVG + XCursor fallback. Tested with Plasma/KWin6.8.2 Wayland.
Experimental zero-delay final-frame morph holds are KWin-specific and not portable.
Raster holding states are static; link/wait/progress animate.
Sizes:24,32,48,60,64,96,128,256. Keep LICENSE with redistributed copies.
